"""
    Ce fichier contiendra la partie Analyse lexicale avec lex de PLY
"""
from ply import lex

"""
Les champs reservés pour l'interpréteur dumbo
"""
reserved = {
    "for": "FOR",
    "do": "DO",
    "endfor": "ENDFOR",
    "if": "IF",
    "else": "ELSE",
    "endif": "ENDIF",
    "in": "IN",
    "print": "PRINT",
    "true": "TRUE",
    "false": "FALSE",
    "or": "OR",
    "and": "AND",
}

"""
Les tokens de l'analyseur lexicale
"""
tokens = [
    "TXT",
    "VARIABLE",
    "BEGINCODE",
    "ENDCODE",
    "LPAREN",
    "RPAREN",
    "ASSIGN",
    "STRING",
    "CONCAT",
    "COMMA",
    "SEMICOLON",
    "NUMBER",
    "PLUS",
    "MINUS",
    "MUL_OP",
    "COMPARATOR",
] + list(reserved.values())

states = (("CODE", "inclusive"), ("TEXT", "inclusive"))


def t_TEXT_BEGINCODE(t):
    r"{{"
    t.lexer.begin("CODE")
    return t


def t_CODE_ENDCODE(t):
    r"}}"
    t.lexer.begin("TEXT")
    return t


t_TEXT_TXT = r'[a-zA-Z0-9:,;&<>"./\\\n\t _-]+'
t_CODE_LPAREN = r"\("
t_CODE_RPAREN = r"\)"
t_CODE_ASSIGN = r":="
t_CODE_CONCAT = r"\."
t_CODE_COMMA = r","
t_CODE_SEMICOLON = r";"
t_CODE_PLUS = r"\+"
t_CODE_MINUS = r"-"
t_CODE_MUL_OP = r"[*/]"
t_CODE_COMPARATOR = r"[<>=]|!="


def t_CODE_NUMBER(t):
    r"\d+(\.\d*)?"
    try:
        t.value = int(t.value)
    except:
        t.value = float(t.value)
    return t


def t_CODE_VARIABLE(t):
    r"[a-zA-Z0-9_]+"
    t.type = reserved.get(t.value, "VARIABLE")  # Check for reserved words
    return t


def t_CODE_STRING(t):
    r'\'[a-zA-Z0-9=:,;&<>"./\\\n\t _-]+\''
    t.value = t.value[1:-1]  # remove ' at the begining and the end of string
    return t


def t_newline(t):
    r"\n+"
    t.lexer.lineno += len(t.value)


t_CODE_ignore = " \t"


def t_error(t):
    print("Illegalcharacter '{}' at line {}".format(t.value[0], t.lexer.lineno))
    t.lexer.skip(1)


lexer = lex.lex()
lexer.begin("TEXT")

if __name__ == "__main__":
    import sys

    # lexer.input(sys.stdin.read())
    file = open(sys.argv[1]).read()
    lexer.input(file)

    for token in lexer:
        print("line %d : %s (%s) " % (token.lineno, token.type, token.value))
