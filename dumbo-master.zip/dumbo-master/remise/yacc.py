"""
Ce fichier contient la partie analyse syntaxique avec yacc de PLY
"""
from ply import yacc, lex
from lex import tokens

"""
La création de l'arbre a été inspiré de la documentation : https://www.dabeaz.com/ply/PLYTalk.pdf p.55-56
"""


def p_program_TXT(p):
    """ program : TXT
                | TXT program """
    if len(p) == 2:
        p[0] = [p[1]]
    elif len(p) == 3:
        p[0] = [p[1]] + p[2]


def p_program_CODE(p):
    """ program : code
                | code program """
    if len(p) == 2:
        p[0] = p[1]
    elif len(p) == 3:
        p[0] = p[1] + p[2]


def p_code_CODE(p):
    """ code : BEGINCODE expressions_list ENDCODE """
    p[0] = p[2]


def p_code_EMPTY(p):
    """ code : BEGINCODE ENDCODE """
    p[0] = []


def p_expressions_list(p):
    """ expressions_list : expression SEMICOLON expressions_list
                    | expression SEMICOLON """
    if len(p) == 4:
        p[0] = [p[1]] + p[3]
    elif len(p) == 3:
        p[0] = [p[1]]


def p_expression(p):
    """ expression : PRINT string_expression
                    | FOR VARIABLE IN string_list DO expressions_list ENDFOR
                    | FOR VARIABLE IN VARIABLE DO expressions_list ENDFOR """
    if len(p) == 3:
        p[0] = ("print", p[2])
    elif len(p) == 8:
        p[0] = ("for", p[2], p[4], p[6])


def p_expression_assignment(p):
    """ expression : VARIABLE ASSIGN string_expression
                    | VARIABLE ASSIGN string_list
                    | VARIABLE ASSIGN boolean_expression """
    # print(p[1], " = ", p[3])
    p[0] = ("assign", p[1], p[3])


def p_expression_if(p):
    """ expression : IF boolean_expression DO expressions_list ENDIF
                    | IF boolean_expression DO expressions_list ELSE expressions_list ENDIF """
    if len(p) == 6:
        p[0] = ("if", p[2], p[4])
    elif len(p) == 8:
        p[0] = ("if", p[2], p[4], p[6])


def p_string_expression(p):
    """ string_expression : string
                            | string CONCAT string_expression """
    if len(p) == 2:
        p[0] = p[1]
    elif len(p) == 4:
        # p[0] = p[1] + p[3]
        p[0] = ("concatenation", p[1], p[3])


def p_string(p):
    """ string : STRING
                | subexpression """
    p[0] = p[1]


def p_subexpression(p):
    """subexpression : VARIABLE
                        | number_expression """
    p[0] = p[1]


def p_string_list(p):
    """ string_list : LPAREN string_list_interior RPAREN """
    p[0] = p[2]


def p_string_list_interior(p):
    """ string_list_interior : STRING
                                | STRING COMMA string_list_interior """
    if len(p) == 2:
        p[0] = [p[1]]
    elif len(p) == 4:
        p[0] = [p[1]] + p[3]


def p_number_expression_num(p):
    """ number_expression : NUMBER """
    p[0] = str(p[1])


def p_number_expression_op(p):
    """ number_expression : subexpression PLUS subexpression
                            | subexpression MINUS subexpression
                            | subexpression MUL_OP subexpression """
    # p[0] = operations[p[2]](p[1], p[3])
    p[0] = (p[2], p[1], p[3])


def p_boolean_expression(p):
    """ boolean_expression : boolean
                            | boolean_expression AND boolean
                            | boolean_expression OR boolean """
    if len(p) == 2:
        p[0] = p[1]
    elif len(p) == 4:
        p[0] = (p[2], p[1], p[3])


def p_sub_boolean_expression(p):
    """ boolean : TRUE
                | FALSE
                | subexpression COMPARATOR subexpression """
    if len(p) == 2:
        p[0] = p[1]
    elif len(p) == 4:
        # p[0] = comparators[p[2]](p[1], p[3])
        p[0] = (p[2], p[1], p[3])


def p_number_expression_uminus(p):
    """ number_expression : MINUS subexpression %prec UMINUS """
    p[0] = -p[2]


def p_error(p):
    print("Syntax error in line {}".format(p.lineno))


precedence = (("left", "PLUS", "MINUS"), ("left", "MUL_OP"), ("right", "UMINUS"))


parser = yacc.yacc(outputdir="generated")

if __name__ == "__main__":
    import sys

    # input = open(sys.argv[1]).read()
    with open(sys.argv[1]) as input:
        result = parser.parse(input.read(), debug=True)

    print(result)
