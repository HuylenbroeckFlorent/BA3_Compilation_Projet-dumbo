from exceptions import *


operations = {
    "+": lambda x, y: str(x + y),
    "-": lambda x, y: str(x - y),
    "*": lambda x, y: str(x * y),
    "/": lambda x, y: str(x / y),
    "<": lambda x, y: x < y,
    ">": lambda x, y: x > y,
    "=": lambda x, y: x == y,
    "!=": lambda x, y: x != y,
}

logical_operations = {"and": lambda x, y: x and y, "or": lambda x, y: x or y}


def is_int(x: str) -> bool:
    """ Check if the string is an integer

        Return boolean value, True if is an integer, False otherwise

        :param x: the string to check
    """
    try:
        int(x)
        return True
    except ValueError:
        return False


def is_float(x: str) -> bool:
    """ Check if the string is a float
        Return a boolean value, True if it's a float, False otherwise

        :param x: the string to check
    """
    try:
        float(x)
        return True
    except ValueError:
        return False


def is_str(x: object) -> bool:
    """ Check if the object is a string
        Return a bool value, True it's a string, False otherwise

        :param x: the object to check
    """
    return isinstance(x, str)


def is_tuple(x: object) -> bool:
    """ Check if the object is a tuple
        Return a bool value, True it's a tuple, False otherwise

        :param x: the object to check
    """
    return isinstance(x, tuple)


def number(x) -> float:
    """ Cast the string into an integer or float.
        If yes, then return cast the string into a number (integer or float).
        Otherwise, raise an exception ValueError

        :param x: the string to cast
    """
    if is_int(x):
        return int(x)
    elif is_float(x):
        return float(x)
    else:
        raise ValueError


class Dumbo:
    def __init__(self, variables):
        self.variables = variables
        self.variables["for"] = {}
        self.for_variables = variables["for"]

    def is_variable(self, variable) -> str:
        """ Check if the string is a variable
            if yes, then return the value of this variable
            Otherwise, return the string

            :param variable: the string to looking for in the dictionnary of variables
        """
        if variable in self.for_variables:
            return self.for_variables[variable]
        if variable in self.variables:
            return self.variables[variable]
        else:
            return variable

    def dumbo_assign(self, variable: str, value, for_loop: bool = False) -> None:
        if is_tuple(value):
            value = self.dumbo_function(value, for_loop)

        if for_loop:
            if variable in self.variables:
                self.variables[variable] = value
            else:
                self.for_variables[variable] = value
        else:
            self.variables[variable] = value

    def dumbo_concatenation(self, elem, other_elem):
        elem = self.is_variable(elem)

        if is_tuple(other_elem):
            return elem + self.dumbo_function(other_elem)
        else:
            return elem + self.is_variable(other_elem)

    def dumbo_for(self, variable, name, instructions) -> str:
        if name in self.variables:
            array = self.variables[name]
        else:
            raise VariableNotDeclared(name)

        res = ""
        dictionary = {}

        for i in range(len(array)):
            self.for_variables[variable] = array[i]

            for instruction in instructions:
                if self.for_variables:
                    dictionary.update(self.for_variables)
                else:
                    self.for_variables.update(dictionary)

                res += self.dumbo_function(instruction, True)

        # the loop for is end, then the variables declared in loop for must be deleted to respect the scope of variable
        self.for_variables.clear()

        return res

    def dumbo_if(
        self, bool_expression, body, body_else=None, for_loop: bool = False
    ) -> str:
        if is_tuple(bool_expression):
            bool_expression = self.dumbo_function(bool_expression, for_loop)

        if bool_expression:
            res = ""

            for instruction in body:
                res += self.dumbo_function(instruction, for_loop)

            return res
        else:
            if body_else == None:
                return ""
            else:
                res = ""
                for instruction in body_else:
                    res += self.dumbo_function(instruction, for_loop)

                return res

    def dumbo_print(self, elem) -> str:
        if isinstance(elem, str):
            return self.is_variable(elem)
        return self.dumbo_function(elem)

    def dumbo_function(self, instructions: tuple, for_loop: bool = False) -> str:
        """ execute function valid in dumbo language

            the functions supported in Dumbo:
                - assign
                - for
                - if
                - concatenation
                - print
                - operations : +, -, *, /
                - logical operations

            :param instructions: a tuple to analysis and execute
        """
        name = instructions[0]

        if name == "assign":
            variable, value = instructions[1:]

            self.dumbo_assign(variable, value, for_loop)

            return ""
        if name == "concatenation":
            el1, el2 = instructions[1:]

            return self.dumbo_concatenation(el1, el2)
        elif name == "for":
            variable, name, instructions = instructions[1:]

            return self.dumbo_for(variable, name, instructions)
        elif name == "if":
            if len(instructions[1:]) == 2:
                bool_expression, body_if = instructions[1:]
                body_else = None
            else:
                bool_expression, body_if, body_else = instructions[1:]

            return self.dumbo_if(bool_expression, body_if, body_else, for_loop)
        elif name == "print":
            return self.dumbo_print(instructions[1])
        elif name in operations:
            element = self.is_variable(instructions[1])
            other_elem = self.is_variable(instructions[2])

            return operations[name](number(element), number(other_elem))
        elif name in logical_operations:
            if is_tuple(instructions[1]):
                element = self.dumbo_function(instructions[1], for_loop)

            if is_tuple(instructions[2]):
                other_elem = self.dumbo_function(instructions[2], for_loop)

            return logical_operations[name](
                self.is_variable(element), self.is_variable(other_elem)
            )
        else:
            raise FunctionNotExists(
                "this function {} doesn't exist in dumbo language...".format(name)
            )
