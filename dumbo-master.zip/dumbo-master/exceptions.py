class CustomException(Exception):
    message = ""

    def __init__(self, title, message):
        self.title = title
        self.message = message

    def __str__(self):
        return "{}: {}".format(self.title, self.message)


class DumboFileNotValid(CustomException):
    def __init__(self, message=None):
        super().__init__("DumboFileNotValid", "the file is not a valid dumbo file...")

        if message != None:
            self.message = message

    def __str__(self):
        return super().__str__()


class DataFileNotValid(CustomException):
    def __init__(self, message=None):
        super().__init__("DataFileNotValid", "this data file is not valid...")

        if message != None:
            self.message = message

    def __str__(self):
        return super().__str__()


class FunctionNotExists(CustomException):
    def __init__(self, message=None):
        super().__init__(
            "FunctionNotExists", "this function isn't exist or is not valid..."
        )

        if message != None:
            self.message = message

    def __str__(self):
        return super().__str__()


class VariableNotDeclared(CustomException):
    def __init__(self, variable):
        return super().__init__(
            "VariableNotDeclared", "the variable {} isn't declared...".format(variable)
        )

    def __str__(self):
        return super().__str__()
