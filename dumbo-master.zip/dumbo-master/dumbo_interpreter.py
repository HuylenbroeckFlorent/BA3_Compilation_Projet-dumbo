import os
from yacc import parser
from exceptions import (
    DumboFileNotValid,
    DataFileNotValid,
    FunctionNotExists,
    VariableNotDeclared,
)
from dumbo_function import Dumbo


def check_extension(file: str, extension: str = "dumbo") -> bool:
    """ check if the extension of the file have de correct extension

        :param file: the path to access to file
        :param extension: the extension that the file must have. By default, the extension is dumbo

        Return :
            - True if the file have the correct extension.
            - False otherwise.
    """
    ext = file.split(".").pop()

    if ext == extension:
        return True
    else:
        return False


def is_dumbo_file(file: str) -> str:
    """ check if the file is a dumbo file
        if yes, then return the file, otherwise throw an exception

        Exception :
            2 type of exception can arrive :
                - FileNotFoundError : this error arrive if the path is not a file
                - Exception : this error arrive if the file isn't a dumbo file
    """
    if os.path.isfile(file):
        if check_extension(file):
            return file
        else:
            raise DumboFileNotValid(
                "Error, {} is not valid, it must be a dumbo file (extension: dumbo) !".format(
                    file
                )
            )
    else:
        raise FileNotFoundError


def retrieve_data(file: str) -> dict:
    """ retrieve all data in the file,
        return a dictionary where the key is the variable
        and the value is the value of the variable

        :param file: the file contains only data
    """
    variables = {}
    with open(file, "r") as data_file:
        data = parser.parse(data_file.read(), debug=False)

        for element in data:
            if isinstance(element, tuple):
                name, variable, value = element

                if name == "assign":
                    variables[variable] = value
                else:
                    raise DataFileNotValid

    return variables


def interprete_template(path: str, variables: dict) -> str:
    """ interprete the template in using the extracted data in the data file
        to replace all varaibles in the template file by their value

        :param path: the path for the template file

        return string containing the final result after interprete all codes correctly.
    """
    result = ""
    try:
        with open(path, "r") as file:
            template = parser.parse(file.read(), debug=False)

            if template != None:
                for element in template:
                    if isinstance(element, str):
                        # All text outside block of code
                        result += element
                    elif isinstance(element, tuple):
                        result += Dumbo(variables).dumbo_function(element)

        return result
    except ValueError as error:
        print(error)
        return ""
    except FunctionNotExists as error:
        print(error)
        return ""
    except VariableNotDeclared as error:
        print(error)
        return ""


def dumbo_interpreter(files: list, output_file: str) -> None:
    """ The main interpretor for dumbo language

        this function retrieve the data in the first file containing in the list
        and apply the template in the second file in the list to write the final result
        in the output_file.

        If the output_file doesn't exist then the file is created.

        :param files: list of files contains name of the data file and the template file
    """
    output_dir = "output/"

    try:
        variables = retrieve_data(files[0])

        # Display the dictionary containing the data with the variables as key and theirs values as value
        # print(variables)

        result = interprete_template(files[1], variables)

        if not os.path.exists(output_dir):
            # create the directory output if isn't already created
            os.makedirs(output_dir)

        with open(output_dir + output_file, "w") as file:
            # write the final result in the output_file
            file.write(result)
    except DataFileNotValid as error:
        print(error)


if __name__ == "__main__":
    import sys

    if len(sys.argv) == 4:
        try:
            dumbo_interpreter([is_dumbo_file(i) for i in sys.argv[1:3]], sys.argv[3])
        except FileNotFoundError as file_not_found:
            print("Error, the data file or template file is not found !")
        except DumboFileNotValid as error:
            print(error)
    else:
        print("Error, the number of arguments is incorrect...")
        print("The program dumbo_interpreter wait to have 3 arguments :")
        print("\t1. The data file")
        print("\t2. The template file")
        print("\t3. The output file")
        print(
            "For example, we create a html file :\n"
            + "python dumbo_interpreter data_file.dumbo template_file.dumbo output.html"
        )
